VITALYNX BRAND ASSETS
=====================
v1.0 — Brand folio and logo asset bundle

────────────────────────────────────────────────────────
HOW TO USE
────────────────────────────────────────────────────────
1. Open brand-guide/vitalynx-brand-guide.html in any browser
   to see the full brand specification. To save as PDF:
   File → Print → Save as PDF.

2. For designers: hand over the contents of the svg/ folder.
   These are vector files that scale to any size.

3. For developers: use the png/ folder for product UI, the
   favicon/ folder for website favicons, and svg/ for any
   place that supports vector graphics (most modern browsers).

────────────────────────────────────────────────────────
CONTENTS
────────────────────────────────────────────────────────

📁 svg/   — Vector files (preferred for production)
   vitalynx-mark.svg                Primary mark (full colour)
   vitalynx-mark-mono-teal.svg      Mark in monochrome teal
   vitalynx-mark-reverse.svg        Mark for dark backgrounds (cream)
   vitalynx-wordmark.svg            Wordmark only with amber Y
   vitalynx-logo-horizontal.svg     Primary lockup, horizontal
   vitalynx-logo-vertical.svg       Primary lockup with tagline
   vitalynx-app-icon.svg            Square app icon (1024×1024)
   vitalynx-favicon.svg             Minimal V on amber

📁 png/   — Raster exports at multiple sizes
   Mark:           200, 400, 800 px (square)
   Wordmark:       120, 200, 400 px (height)
   Horizontal:     200, 400, 800 px (mark height)
   Vertical:       240, 400, 600 px (mark height)
   Mono teal:      200, 400 px
   Reverse:        200, 400 px
   App icon:       1024, 512, 192, 180, 167, 152, 120, 87,
                   80, 76, 60, 40 px (covers iOS + Android)

📁 favicon/   — Website favicon set
   favicon.ico                Multi-resolution (16-256px)
   favicon-16.png             Browser tab
   favicon-32.png             Browser tab (retina)
   favicon-48.png             Windows site tile
   favicon-64.png             High-DPI tab
   favicon-96.png             Android Chrome
   favicon-128.png            Chrome Web Store
   favicon-192.png            Android home screen
   favicon-256.png            Modern desktop
   favicon-512.png            PWA / web manifest

📁 brand-guide/
   vitalynx-brand-guide.html  Self-contained brand folio
                              (open in browser, print to PDF)

────────────────────────────────────────────────────────
COLOUR SYSTEM
────────────────────────────────────────────────────────
Petrol teal  #114E5C   RGB 17, 78, 92      Primary
Amber gold   #E6A847   RGB 230, 168, 71    Accent
Cream        #FAF6EE   RGB 250, 246, 238   Surface
Deep petrol  #0A3942   RGB 10, 57, 66      Dark text

────────────────────────────────────────────────────────
TYPOGRAPHY
────────────────────────────────────────────────────────
Playfair Display (Bold 700)   Wordmark, headings
Inter (Regular 400, Medium 500)  Body, UI, tagline

Both fonts are free via Google Fonts:
https://fonts.google.com/specimen/Playfair+Display
https://fonts.google.com/specimen/Inter

────────────────────────────────────────────────────────
WEB DEPLOYMENT (favicons)
────────────────────────────────────────────────────────
Add to your site's <head>:

<link rel="icon" type="image/svg+xml" href="/favicon/vitalynx-favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16.png">
<link rel="apple-touch-icon" sizes="192x192" href="/favicon/favicon-192.png">
<link rel="shortcut icon" href="/favicon/favicon.ico">

────────────────────────────────────────────────────────
IMPORTANT NOTES FOR YOUR DESIGNER
────────────────────────────────────────────────────────
1. The SVG files reference Playfair Display and Inter via
   Google Fonts CDN. For maximum portability in production,
   convert all text inside SVGs to paths (Illustrator:
   Type → Create Outlines; Inkscape: Path → Object to Path).

2. The V inside the central mark uses Playfair Display
   Bold. Consider whether to keep this serif V tied to the
   wordmark typeface, or switch to a geometric V for
   independence from the wordmark.

3. PNGs are exported at sufficient sizes for app stores,
   web, and most print uses. For large-format print (signage,
   billboards), use the SVG versions or commission new
   high-resolution exports.

4. The colour values above are sRGB / web. For accurate
   print, ask your printer for PMS (Pantone) approximations
   and request a colour proof before any major print run.

────────────────────────────────────────────────────────
NEXT STEPS
────────────────────────────────────────────────────────
□ Have a designer review and refine kerning, proportions,
  and produce final production-quality vector files.
□ Conduct trademark clearance (IP India, classes 9, 42, 44).
□ Register .com, .in, .health domains.
□ Reserve "Vitalynx" on iOS App Store and Google Play.
□ Set up brand guidelines document for future contributors.

────────────────────────────────────────────────────────
Vitalynx — Health · Connected · Empowered
